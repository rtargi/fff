import { DossierData } from './types';

export const dossierData: DossierData = {
  "pageTitle": "O Dossier do Audiovisual: TOTALMENTE FORA DA TERRA",
  "header": {
    "title": {
      "part1": "TOTALMENTE",
      "part2": "FORA DA",
      "part3": "TERRA"
    },
    "subtitle": "O diagnóstico da irresponsabilidade socioambiental e negligência climática da ANCINE e do Fundo Setorial do Audiovisual.",
    "callToAction": {
      "text": "Entenda a Denúncia",
      "link": "#prova-omissao"
    }
  },
  "sections": [
    {
      "id": "resumo",
      "title": "LOUCURA TOTAL: ANCINE E FSA OPERAM NO VÁCUO CLIMÁTICO",
      "content": "Como a tentativa de realizar um projeto de educação climática no maior palco ambiental do planeta — a COP30 — revelou um escandaloso APAGÃO CLIMÁTICO na Ancine Fora da Terra. Com 500 funcionários e R$ 171 milhões anuais em orçamento, a agência nunca sequer abordou a pegada de carbono do próprio setor audiovisual.\n\nO modelo industrial do audiovisual brasileiro, que já faliu comercialmente (apenas 3% de participação na bilheteria após 20 anos do FSA) e desperdiça bilhões de reais em fomento irrelevante, demonstra uma desconexão gritante com a realidade brasileira e os imperativos climáticos globais. A política audiovisual, presa a um paradigma de século XX, parece alheia à emergência climática.",
      "keyStats": [
        {"label": "Anos de FSA com negligência climática", "value": "20+"},
        {"label": "Percentual de investimento em clima", "value": "0%"},
        {"label": "Orçamento Anual ANCINE", "value": "R$ 171 milhões"},
        {"label": "Tamanho da força de trabalho ANCINE", "value": "500 funcionários"}
      ]
    },
    {
      "id": "linha-do-tempo",
      "title": "A LINHA DO TEMPO: A DESCOBERTA DO APAGÃO",
      "events": [
        {
          "monthYear": "Dezembro de 2024",
          "title": "O Protocolo",
          "description": "Protocolamos o projeto “COP30: Janela de Oportunidade”, uma experiência imersiva de educação climática e sensibilização pública. Um projeto de evidente interesse público, pronto para ser executado."
        },
        {
          "monthYear": "Janeiro a Junho de 2025",
          "title": "O Labirinto",
          "description": "Durante seis meses, enfrentamos o silêncio administrativo, reclassificações absurdas e a inércia de um fundo incapaz de reagir à urgência climática. A burocracia se revelou uma muralha contra o futuro."
        },
        {
          "monthYear": "Julho de 2025",
          "title": "A Sugestão de Cortes",
          "description": "A resposta do BRDE — o chamado “Banco Verde” — foi pedir cortes em um orçamento já mínimo para uma ação pública climática de alcance internacional. Negaram financiamento."
        },
        {
          "monthYear": "Julho de 2025",
          "title": "A Fronteira do Patrimônio",
          "description": "A exigência final: “falta de suporte patrimonial”. Isso significa que o FSA não é para quem propõe ideias urgentes, mas para quem herda imóveis, empresas ou redes de influência. O fundo público mais poderoso do Brasil foi capturado por uma elite que não tem projeto, não tem coragem e não tem compromisso com o país."
        }
      ]
    },
    {
      "id": "prova-omissao",
      "title": "PARTE I: A PROVA DOCUMENTAL DA OMISSÃO",
      "chapters": [
        {
          "title": "A CONFISSÃO DA ANCINE: 'NÃO HÁ DIAGNÓSTICO'",
          "description": "A investigação via Lei de Acesso à Informação (LAI) produziu um dossiê irrefutável. A prova central é a resposta oficial da própria ANCINE, uma confissão de sua inação.",
          "quote": {
            "text": "Não há diagnóstico nesse sentido, tendo em vista que o tema dos projetos não faz parte dos critérios de seleção das chamadas públicas.",
            "source": "Resposta Oficial da ANCINE (NUP 01481.000634/2025-26)"
          },
          "keyNumbers": [
            {"label": "Recursos destinados a projetos com foco explícito em justiça climática em mais de R$ 2 bilhões movimentados:", "value": "0,00"}
          ],
          "omissionTable": [
            {"pergunta": "O FSA possui critérios climáticos na seleção?", "resposta": "Não há diagnóstico nesse sentido...", "implicacao": "Omissão Institucional Sistematizada."},
            {"pergunta": "É exigido o inventário da pegada de carbono?", "resposta": "Confirma a ausência de qualquer exigência.", "implicacao": "Irresponsabilidade Socioambiental."},
            {"pergunta": "Existem linhas de fomento para a COP 30?", "resposta": "não há registro de discussões...", "implicacao": "Desperdício de Soft Power."},
            {"pergunta": "Qual o valor total destinado ao clima (2022-24)?", "resposta": "Não fornece os dados, confessando a inexistência.", "implicacao": "Gestão Cega e Ausência de Controle."}
          ]
        },
        {
            "title": "2 - O NEGACIONISMO É FORA DA LEI E CONTRA ORDENAMENTO JURÍDICO",
            "description": "A omissão não é apenas má gestão, mas um \"deliberado desacordo com o ordenamento jurídico nacional\". A inércia coloca o FSA em rota de colisão com as leis que o país jurou cumprir.",
            "legalPoints": [
              {
                "icon": "🇧🇷",
                "title": "Política Nacional sobre Mudança do Clima",
                "description": "A Lei nº 12.187/2009 é ignorada ao não se compatibilizar o desenvolvimento do setor com a proteção do sistema climático."
              },
              {
                "icon": "🌍",
                "title": "Acordo de Paris",
                "description": "O Brasil, como signatário, tem o dever de integrar o clima em TODAS as políticas públicas, incluindo a cultural."
              },
              {
                "icon": "🇺🇳",
                "title": "Objetivos de Desenvolvimento Sustentável",
                "description": "A inação desrespeita o ODS 13 (Ação Climática) e o ODS 12 (Produção Responsável)."
              }
            ]
        },
        {
          "title": "3 - RELATÓRIOS CONFIRMAM A NEGLIGÊNCIA DO ALOPRADO COMITÊ GESTOR QUE GASTOU BILHÕES NA MAIOR IRRESPONSABILIDADE",
          "description": "A negligência é confirmada pela análise dos próprios Relatórios de Gestão. A ausência de dados e menções ao clima revela uma cultura de \"gestão cega\", que opera sem transparência e desperdiça recursos em um paradigma falido.",
          "analysis": "Entre 2020 e 2024, os relatórios do BRDE, o autointitulado \"Banco Verde\", não contêm <strong class=\"text-red-400 underline\">uma única menção</strong> à COP 30 ou à crise climática. A agenda climática sequer existe no léxico da gestão do FSA."
        }
      ]
    },
    {
      "id": "conclusao",
      "title": "", // Not used in the new design
      "mainTitle": {
        "part1": "O APAGÃO ESTÁ ",
        "part2": "DOCUMENTADO",
        "part3": ".<br>A AÇÃO É ",
        "part4": "URGENTE"
      },
      "conclusionDescription": "O Brasil não pode permitir a irresponsabilidade brutal do <strong class=\"text-yellow-400\">QUARTO DE BRINQUEDOS</strong> que custa caríssimo à Nação abandonada à própria vulnerabilidade climática.",
      "whatWeveDone": {
        "title": "O QUE JÁ FIZEMOS?",
        "description": "Diante deste quadro de \"loucura total\", onde o audiovisual brasileiro parece estar \"TOTALMENTE FORA DA TERRA\", agimos com uma estratégia multifacetada para romper com essa inércia:",
        "items": [
          {
            "icon": "⚖️",
            "title": "Direito de Petição e Recurso Hierárquico",
            "description": "Formalizamos denúncias e exigimos medidas emergenciais, incluindo a criação de linhas de fomento climático e a participação social na governança."
          },
          {
            "icon": "📂",
            "title": "Base Documental",
            "description": "Compilamos provas irrefutáveis da omissão e ilegalidade, agora publicadas nesta página."
          },
          {
            "icon": "⚡",
            "title": "Ação Urgente",
            "description": "Exigimos da ANCINE e do CGFSA medidas concretas e imediatas para que o setor se torne um protagonista na transição ecológica."
          }
        ]
      },
      "callToActionTitle": "AJUDE A TIRAR O AUDIOVISUAL DO QUARTO DE BRINQUEDOS",
      "actionButtons": [
        {
          "id": "open-petition-modal-btn",
          "text": "APOIE AS PETIÇÕES",
          "url": "#",
          "variant": "primary"
        },
        {
          "text": "SAIBA MAIS SOBRE O QUARTO DE BRINQUEDOS",
          "url": "#dossie",
          "variant": "secondary"
        }
      ]
    }
  ],
  "footer": {
    "text": "Este dossiê é um chamado à mobilização. É hora de resgatar o FSA e transformá-lo num motor para construir o maior bioma cultural da Terra.",
    "copyright": "© 2025 Films For Future. Uma proposta para um futuro possível."
  }
};